import express from 'express';
import cors from 'cors';
import mysql from 'mysql2';

// Initialize the Express app
const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MySQL database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'flight_system'
});

// Connect to the MySQL database
db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    process.exit(1); // Stop the server if the DB connection fails
  }
  console.log('Connected to the MySQL database');
});

// API route to fetch locations from the database
app.get("/api/locations", (req, res) => {
  // Query the 'airports' table to get all airport data
  db.query('SELECT airport_name FROM airport_1', (err, results) => {
    if (err) {
      console.error("Error fetching locations from DB:", err); // Logs the error
      return res.status(500).json({ message: "Internal Server Error" });
    }

    // Use the results directly
    res.status(200).json(results);
  });
});

app.post('/api/search-flights', (req, res) => {
  const { fromLocation, toLocation, tripDate } = req.body;

  // Query to fetch flights based on parameters
  const query = `
        SELECT * FROM synthetic_flight_data 
        WHERE origin_location = ? 
        AND destination_location = ? 
        AND flight_date = ?
    `;

  db.query(query, [fromLocation, toLocation, tripDate], (err, results) => {
    if (err) {
      console.error("Error fetching flights from DB:", err);
      return res.status(500).json({ message: "Internal Server Error" });
    }

    res.status(200).json(results);
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
