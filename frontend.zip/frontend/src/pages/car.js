import React, { useState } from 'react';
import './App1.css';
import sedanImg from './sedan.jpg';
import suvImg from './suv.jpg';
import convertibleImg from './convertible.jpg';
import truckImg from './truck.jpg';

export default function Car() {
    const [selectedCar, setSelectedCar] = useState('');
    const [rentalDate, setRentalDate] = useState('');
    const [returnDate, setReturnDate] = useState('');
    const [rentalDetails, setRentalDetails] = useState(null);

    const cars = [
        { model: 'Sedan', price: 50, image: sedanImg },
        { model: 'SUV', price: 80, image: suvImg },
        { model: 'Convertible', price: 100, image: convertibleImg },
        { model: 'Truck', price: 120, image: truckImg },
    ];

    

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!selectedCar || !rentalDate || !returnDate) {
            alert('Please fill in all fields');
            return;
        }

        const carDetails = cars.find(car => car.model === selectedCar);

        setRentalDetails({
            car: selectedCar,
            rentalDate,
            returnDate,
            price: carDetails.price,
            image: carDetails.image,
        });
    };

    const handleBook = () => {
        alert(`Booking confirmed for ${rentalDetails.car}!`);
        // You can replace this with actual booking logic or navigation
    };

    return (
        <div className="container">
            <h1>Car Rental Service</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Car Model:</label>
                    <select
                        value={selectedCar}
                        onChange={(e) => setSelectedCar(e.target.value)}
                    >
                        <option value="">Select a car</option>
                        {cars.map((car, index) => (
                            <option key={index} value={car.model}>
                                {car.model}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label>Rental Date:</label>
                    <input
                        type="date"
                        value={rentalDate}
                        onChange={(e) => setRentalDate(e.target.value)}
                    />
                </div>

                <div>
                    <label>Return Date:</label>
                    <input
                        type="date"
                        value={returnDate}
                        onChange={(e) => setReturnDate(e.target.value)}
                    />
                </div>

                <button type="submit">Submit</button>
            </form>

            {rentalDetails && (
                <div className="rental-summary">
                    <h2>Rental Summary</h2>
                    <p>
                        <strong>Car Model:</strong> {rentalDetails.car}
                    </p>
                    <p>
                        <strong>Rental Date:</strong> {rentalDetails.rentalDate}
                    </p>
                    <p>
                        <strong>Return Date:</strong> {rentalDetails.returnDate}
                    </p>
                    <p>
                        <strong>Price per Day:</strong> ${rentalDetails.price}
                    </p>
                    <div>
                        <img
                            src={rentalDetails.image}
                            alt={rentalDetails.car}
                            style={{ width: '200px', height: 'auto' }}
                        />
                    </div>

                    <button onClick={handleBook} className="book-button">
                        Book Now
                    </button>
                </div>
            )}
        </div>
    );
}
