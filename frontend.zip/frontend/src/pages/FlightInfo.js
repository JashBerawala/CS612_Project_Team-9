import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Paper, Box, Typography, Stack, Divider, CircularProgress, Grid, Button } from '@mui/material';

export default function ViewFlightInfo() {
    const location = useLocation();
    const { tripType, classType, tripDate, returnDate, passengerCount, fromLocation, toLocation } = location.state || {};

    const [flights, setFlights] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch flights from the backend
        const fetchFlights = async () => {
            try {
                const response = await fetch('http://localhost:5000/api/search-flights', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        fromLocation: fromLocation?.label,
                        toLocation: toLocation?.label,
                        tripDate
                    })
                });

                const data = await response.json();
                setFlights(data);
            } catch (error) {
                console.error('Error fetching flights:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchFlights();
    }, [fromLocation, toLocation, tripDate]);

    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px' }}>
            <Paper elevation={8} sx={{ padding: 3, maxWidth: 1200, width: '100%', marginBottom: 3 }}>
                <Box sx={{ marginBottom: 2, textAlign: 'center' }}>
                    <Typography variant="h4" gutterBottom>
                        Flight Information
                    </Typography>
                    <Divider sx={{ marginBottom: 2 }} />
                </Box>

                <Stack direction="row" spacing={4} justifyContent="center" sx={{ marginBottom: 2 }}>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">Trip Type: {tripType === 'roundTrip' ? 'Round Trip' : 'One Way'}</Typography>
                    </Box>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">Class Type: {classType}</Typography>
                    </Box>
                </Stack>

                <Stack direction="row" spacing={4} justifyContent="center" sx={{ marginBottom: 2 }}>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">From: {fromLocation?.label}</Typography>
                    </Box>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">To: {toLocation?.label}</Typography>
                    </Box>
                </Stack>

                <Stack direction="row" spacing={4} justifyContent="center" sx={{ marginBottom: 2 }}>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">Trip Date: {tripDate}</Typography>
                    </Box>
                    {tripType === 'roundTrip' && (
                        <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                            <Typography variant="h6">Return Date: {returnDate}</Typography>
                        </Box>
                    )}
                </Stack>

                <Box sx={{ display: 'flex', justifyContent: 'center', marginBottom: 2 }}>
                    <Box sx={{ padding: 2, border: '1px solid #ccc', borderRadius: '4px', width: '45%' }}>
                        <Typography variant="h6">Passengers: {passengerCount}</Typography>
                    </Box>
                </Box>
            </Paper>

            {/* New Feature: Flight Options */}
            <Paper elevation={8} sx={{ padding: 3, maxWidth: 1200, width: '100%' }}>
                <Box sx={{ marginBottom: 2, textAlign: 'center' }}>
                    <Typography variant="h5" gutterBottom>
                        Available Flight Options
                    </Typography>
                    <Divider sx={{ marginBottom: 2 }} />
                </Box>

                {loading ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100px' }}>
                        <CircularProgress />
                    </Box>
                ) : flights.length === 0 ? (
                    <Typography sx={{ textAlign: 'center' }}>No flights available for the selected criteria.</Typography>
                ) : (
                    <Grid container spacing={2}>
                        {flights.map((flight) => (
                            <Grid item xs={12} key={flight.flid}>
                                <Paper elevation={4} sx={{ display: 'flex', padding: 2, alignItems: 'center', justifyContent: 'space-between' }}>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
                                        <Typography variant="h6" sx={{ marginBottom: 1 }}>
                                            {flight.origin_location} → {flight.destination_location}
                                        </Typography>
                                        <Typography variant="body1">
                                            Departure: {flight.departure_time}, Date: {flight.flight_date}
                                        </Typography>
                                        <Typography variant="h6" sx={{ fontWeight: 'bold', marginTop: 1 }}>
                                            {flight.aircraft_company}
                                        </Typography>
                                    </Box>
                                    <Box sx={{ textAlign: 'right' }}>
                                        <Typography variant="h6" color="primary">
                                            ${flight.cost}
                                        </Typography>
                                        <Typography variant="body2" color="error">
                                            Limited seats available
                                        </Typography>
                                        <Button variant="contained" color="primary" sx={{ marginTop: 1 }}>
                                            Book Now
                                        </Button>
                                    </Box>
                                </Paper>
                            </Grid>
                        ))}
                    </Grid>
                )}
            </Paper>
        </div>
    );
}
