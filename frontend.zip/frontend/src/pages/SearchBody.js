import { Paper, Stack } from "@mui/material";
import React, { useState, useEffect } from "react";
import { FormControl, Box, Button, Typography, Autocomplete, TextField } from "@mui/material";
import { InputLabel, Select, MenuItem } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Import useNavigate

export default function SearchBody(props) {
    const navigate = useNavigate(); // Initialize useNavigate
    const [tripType, setTripType] = useState("");
    const [classType, setClassType] = useState("");
    const [tripDate, setTripDate] = useState("");
    const [returnDate, setReturnDate] = useState("");
    const [passengerCount, setPassengerCount] = useState(1); // Initialize passenger count to 1
    const [fromLocation, setFromLocation] = useState(null);
    const [toLocation, setToLocation] = useState(null);
    const [locations, setLocations] = useState([]);

    useEffect(() => {
        const fetchLocations = async () => {
            try {
                const response = await axios.get("http://localhost:5000/api/locations");
                console.log("Locations from API:", response.data);
                setLocations(response.data.map((location) => ({ label: location.airport_name })));
            } catch (error) {
                console.error("Error fetching locations:", error);
            }
        };

        fetchLocations();
    }, []);

    const handleSearch = () => {
        // Pass form data to the /viewflightinfo page using navigate
        navigate('/viewflightinfo', {
            state: {
                tripType,
                classType,
                tripDate,
                returnDate,
                passengerCount,
                fromLocation,
                toLocation
            }
        });
    };

    return (
        <div>
            <Stack direction="column">
                <Paper
                    elevation={8}
                    sx={{
                        padding: 3,
                        maxWidth: 1200,
                        width: "80%",
                        margin: "0 auto",
                    }}
                >
                    <Box sx={{ maxWidth: 1200, width: "80%", margin: "0 auto", padding: 3 }}>
                        <Typography variant="h4" sx={{ marginBottom: 2 }}>
                            Flight Search
                        </Typography>

                        <Box sx={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            {/* Trip Type */}
                            <FormControl fullWidth sx={{ width: "48%" }}>
                                <InputLabel id="trip-type-label">Select Trip Type</InputLabel>
                                <Select
                                    labelId="trip-type-label"
                                    value={tripType}
                                    onChange={(event) => setTripType(event.target.value)}
                                    label="Trip Type"
                                >
                                    <MenuItem value="oneWay">One Way</MenuItem>
                                    <MenuItem value="roundTrip">Round Trip</MenuItem>
                                </Select>
                            </FormControl>

                            {/* Class Type */}
                            <FormControl fullWidth sx={{ width: "48%" }}>
                                <InputLabel id="class-type-label">Select Class Type</InputLabel>
                                <Select
                                    labelId="class-type-label"
                                    value={classType}
                                    onChange={(event) => setClassType(event.target.value)}
                                    label="Class Type"
                                >
                                    <MenuItem value="economy">Economy</MenuItem>
                                    <MenuItem value="business">Business</MenuItem>
                                    <MenuItem value="firstClass">First Class</MenuItem>
                                </Select>
                            </FormControl>
                        </Box>

                        {/* From and To Locations */}
                        <Box sx={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            {/* From Location */}
                            <FormControl fullWidth sx={{ width: "48%" }}>
                                <Autocomplete
                                    disablePortal
                                    id="from"
                                    options={locations}
                                    value={fromLocation}
                                    onChange={(event, newValue) => setFromLocation(newValue)}
                                    getOptionLabel={(option) => option?.label || ""}
                                    renderInput={(params) => <TextField {...params} label="From" />}
                                />
                            </FormControl>

                            {/* To Location */}
                            <FormControl fullWidth sx={{ width: "48%" }}>
                                <Autocomplete
                                    disablePortal
                                    id="to"
                                    options={locations}
                                    value={toLocation}
                                    onChange={(event, newValue) => setToLocation(newValue)}
                                    getOptionLabel={(option) => option?.label || ""}
                                    renderInput={(params) => <TextField {...params} label="To" />}
                                />
                            </FormControl>
                        </Box>

                        {/* Other Input Fields */}
                        <Box sx={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            <TextField
                                label="Trip Date"
                                type="date"
                                value={tripDate}
                                onChange={(event) => setTripDate(event.target.value)}
                                fullWidth
                                InputLabelProps={{ shrink: true }}
                                sx={{ width: "48%" }}
                            />
                            {tripType === "roundTrip" && (
                                <TextField
                                    label="Return Date"
                                    type="date"
                                    value={returnDate}
                                    onChange={(event) => setReturnDate(event.target.value)}
                                    fullWidth
                                    InputLabelProps={{ shrink: true }}
                                    sx={{ width: "48%" }}
                                />
                            )}
                        </Box>

                        {/* Passenger Count and Search Button */}
                        <Box sx={{ display: "flex", justifyContent: "space-between", marginTop: 2 }}>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Typography variant="h6" sx={{ marginRight: 2 }}>
                                    Passengers:
                                </Typography>
                                <Button
                                    onClick={() => setPassengerCount(Math.max(1, passengerCount - 1))}
                                    disabled={passengerCount <= 1}
                                >
                                    -
                                </Button>
                                <Typography sx={{ margin: "0 10px" }}>{passengerCount}</Typography>
                                <Button onClick={() => setPassengerCount(passengerCount + 1)}>+</Button>
                            </Box>
                            <Button variant="contained" color="primary" onClick={handleSearch}>
                                Search
                            </Button>
                        </Box>
                    </Box>
                </Paper>
            </Stack>
        </div>
    );
}
