import React from "react";
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import SearchBody from "./pages/SearchBody";
import FlightInfo from "./pages/FlightInfo";
import Car from "./pages/car";

export default function AppRoutes(props) {


    return(
<BrowserRouter>
    <Routes>
        <Route path='/' element ={<SearchBody/>}/>
        <Route path='/viewflightinfo' element ={<FlightInfo/>}/>
        <Route path='/carrental' element= {<Car/>}/>
    
    </Routes>

</BrowserRouter>
    );
}