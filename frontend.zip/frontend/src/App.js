import logo from './logo.svg';
import './App.css';
import TopNav from './component/TopNav';
import SearchBody from './pages/SearchBody';
import AppRoutes from './AppRoutes';

function App() {
  return (
    <div className="App">
      <TopNav/>
      <div className='main-body'>

      <h1> 
        Welcome To Booking Site
        </h1>
<AppRoutes/>
      </div>
    </div>
  );
}

export default App;
