const createAccountLink = document.getElementById("create-account-link");
const signInLink = document.getElementById("sign-in-link");
const loginForm = document.querySelector(".login-form");
const registerForm = document.querySelector(".register-form");

createAccountLink.addEventListener("click", () => {
    loginForm.classList.add("hidden");
    registerForm.classList.remove("hidden");
});

signInLink.addEventListener("click", () => {
    registerForm.classList.add("hidden");
    loginForm.classList.remove("hidden");
});
